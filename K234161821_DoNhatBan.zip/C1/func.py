def count_c_max(s):
    org_s=s.lower()
    out_s = ""
    count_max = 0
    res_s = ""
    for c in org_s:
        if c != " " and c not in out_s:
            out_s += c
    for c in out_s:
        count = org_s.count(c)
        if count > count_max:
            count_max = count
            res_s = c + ","
        elif count == count_max:
            res_s += c + ","
    return res_s.rstrip(","), count_max


def my_join(lst, s):
    res = ""
    for item in lst:
        res += item + s
    return res.rstrip(s)

"""
HOMEWORK
Định nghĩa hàm "Chuẩn hóa chuỗi"
loại bỏ khoảng trắng dư thừa trong chuỗi
VD: "     kHoa    he    thong    tHong tin  " => "Khoa He Thong Thong Tin"
"""
def chuan_hoa(org_s):
    list=org_s.title().split()
    edit_s=" ".join(list)
    return edit_s

# s="      "
# s=s.strip()
# while True:
#     if s.find("  ") != -1:
#         s=s.replace("  "," ")
#     else:
#         break
# print(s.title())

def process_s(s):
    s=s.strip()
    # Trong khi còn tìm thấy 2 khoảng trắng liên tiếp -> thay thế bằng 1 khoảng trắng
    # while s.count("  ") != 0:
    # while s.find("  ") != -1:
    while "  " in s:
        s=s.replace("  "," ")
    return s.title()



